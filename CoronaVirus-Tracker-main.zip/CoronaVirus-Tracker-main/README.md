# COVID-19 Tracker

## Libraries used:
> Volley
> Glide
> SpinKit

## API -> https://corona.lmao.ninja/


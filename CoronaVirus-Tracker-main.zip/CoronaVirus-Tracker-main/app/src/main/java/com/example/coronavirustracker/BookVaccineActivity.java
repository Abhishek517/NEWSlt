package com.example.coronavirustracker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BookVaccineActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_vaccine);
    }
}